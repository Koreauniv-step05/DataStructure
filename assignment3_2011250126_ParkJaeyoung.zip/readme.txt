### Usage ###
# Install numpy module(Sorry for the external module...
#                      This module is only for random function...)
pip install -r requirements.txt

# run Script
python3 Script.py